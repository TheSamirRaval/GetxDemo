import 'package:device_tracker/di/app_component_base.dart';
import 'package:device_tracker/enum/font_type.dart';
import 'package:device_tracker/ui/common/logger.dart';
import 'package:device_tracker/ui/common/routes.dart';
import 'package:device_tracker/ui/common/strings.dart';
import 'package:device_tracker/ui/common/translation_service.dart';
import 'package:device_tracker/ui/common/utils.dart';
import 'package:device_tracker/ui/common/widgets/app_theme.dart';
import 'package:device_tracker/ui/common/widgets/custom_progress_dialog.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

/*

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int _counter = 0;
  var firestoreInstance;

  @override
  void initState() {
    // Firebase.initializeApp().whenComplete(() {
    //   print("completed");
    //   firestoreInstance = FirebaseFirestore.instance;
    // });
    firestoreInstance = FirebaseFirestore.instance;

    super.initState();
  }

  void _incrementCounter() {
    // setState(() {
    //   _counter++;
    // });

    firestoreInstance.collection("users").add({
      "name": "Samir",
      // "age": 50,
      // "email": "example@example.com",
      // "address": {"street": "street 24", "city": "new york"}
    }).then((value) {
      print(value.id);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            const Text(
              'You have pushed the button this many times:',
            ),
            Text(
              '$_counter',
              style: Theme.of(context).textTheme.headline4,
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _incrementCounter,
        tooltip: 'Increment',
        child: const Icon(Icons.add),
      ), // This trailing comma makes auto-formatting nicer for build methods.
    );
  }
}
*/

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  Firebase.initializeApp().then((value) => runApp(MyApp()));
}

class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return MyAppState();
  }
}

class MyAppState extends State<MyApp> {
  @override
  void initState() {
    AppComponentBase.instance.init();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return AppTheme(
        child: GetMaterialApp(
      debugShowCheckedModeBanner: false,
      enableLog: true,
      logWriterCallback: Logger.write,
      initialRoute: RouteName.INITIAL,
      getPages: Routes.routes,
      locale: TranslationService.locale,
      fallbackLocale: TranslationService.fallbackLocale,
      translations: TranslationService(),
      builder: (context, widget) {
        final _appTheme = AppTheme.of(context);
        ScreenUtil.init(
          BoxConstraints(
              maxWidth: MediaQuery.of(context).size.width,
              maxHeight: MediaQuery.of(context).size.height),
          orientation: Orientation.portrait,
          designSize: Size(
              _appTheme.expectedDeviceWidth, _appTheme.expectedDeviceHeight),
          // allowFontScaling: true
        );
        return Stack(
          children: <Widget>[
            StreamBuilder<bool?>(
                initialData: false,
                stream: AppComponentBase.instance.progressDialogStream,
                builder: (context, snapshot) {
                  return IgnorePointer(
                      ignoring: snapshot.data as bool, child: widget);
                }),
            StreamBuilder<bool?>(
                initialData: true,
                stream: AppComponentBase.instance
                    .getNetworkManager()
                    .internetConnectionStream,
                builder: (context, snapshot) {
                  return SafeArea(
                    child: AnimatedContainer(
                        height: snapshot.data as bool
                            ? 0
                            : _appTheme.getResponsiveHeight(100),
                        duration: Utils.animationDuration,
                        color: _appTheme.redColor,
                        child: Material(
                          type: MaterialType.transparency,
                          child: Center(
                              child: Text(StringConstants.noInternetConnection,
                                  style: _appTheme.customTextStyle(
                                      fontSize: 40,
                                      color: _appTheme.whiteColor,
                                      fontFamilyType: FontFamilyType.ProzaLibre,
                                      fontWeightType: FontWeightType.Medium))),
                        )),
                  );
                }),
            StreamBuilder<bool?>(
                initialData: false,
                stream: AppComponentBase.instance.progressDialogStream,
                builder: (context, snapshot) {
                  return snapshot.data as bool
                      ? Center(child: CustomProgressDialog())
                      : const Offstage();
                })
          ],
        );
      },
    ));
  }

  @override
  void dispose() {
    AppComponentBase.instance.dispose();
    super.dispose();
  }
}
