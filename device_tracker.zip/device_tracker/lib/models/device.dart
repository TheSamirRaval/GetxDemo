// To parse this JSON data, do
//
//     final post = postFromJson(jsonString);

import 'dart:convert';

import 'package:device_tracker/models/user.dart';

class Device {
  Device({
    this.name,
    this.user_id,
    this.user,
    this.id
  });

  String? name;
  String? user_id;
  String? id;
  User? user;


  factory Device.fromRawJson(String str) => Device.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory Device.fromJson(Map<String, dynamic> json) => Device(
        name: json["name"] == null ? null : json["name"],
        user_id: json["user_id"] == null ? null : json["user_id"],
        id: json["id"] == null ? null : json["id"],
      );

  Map<String, dynamic> toJson() => {
        "name": name == null ? null : name,
        "user_id": user_id == null ? null : user_id,
        "id": id == null ? null : id,
      };
}
