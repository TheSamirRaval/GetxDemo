// To parse this JSON data, do
//
//     final post = postFromJson(jsonString);

import 'dart:convert';

class User {
  User({
    this.name,
    this.id,
  });

  String? name;
  String? id;

  factory User.fromRawJson(String str) => User.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory User.fromJson(Map<String, dynamic> json) => User(
        name: json["name"] == null ? null : json["name"],
        id: json["id"] == null ? null : json["id"],
      );

  Map<String, dynamic> toJson() => {
        "name": name == null ? null : name,
        "id": id == null ? null : id,
      };
}
