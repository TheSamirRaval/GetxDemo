import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:device_tracker/models/device.dart';
import 'package:device_tracker/models/user.dart';
import 'package:flutter/material.dart';

class FirestoreManager {
  FirestoreManager._privateConstructor();

  static final FirestoreManager _instance =
      FirestoreManager._privateConstructor();

  static FirestoreManager get instance => _instance;

  static const String userCollection = "users";

  static const String deviceCollection = "devices";

  /* static const String journalCollection = "journals";

  static const String journalCategoryLabel = "category";

  static const String courseCategoriesLabel = "categories";

  static const String coursesLabel = "courses";

  static const String lessonsLabel = "lessons";

  static const String quizLabel = "quiz";

  static const String profileLabel = "profile";

  static const String courseProgression = "course_progression";

  static const String courseIdLabel = "lp_courses_";

  static const String quizIdLabel = "lp_quiz_";

  static const String journalCategory = "journal_categories";
  static const String writeJournalImages = "write_journal_images";

  var journalCategories = <JournalCategory>[].obs;

  var courseCategories = <CourseCategory>[].obs;

  Rx<bool> loadingJournalCategories = false.obs;

  Rx<bool> loadingCategories = false.obs;


  bool hasJournalCategory(String category) {
    if (journalCategories.contains(category)) {
      return true;
    }
    return false;
  }*/

  /*List<JournalCategory> defaultJournalCategories = [
    JournalCategory(
        image:
            "https://firebasestorage.googleapis.com/v0/b/level108-dev.appspot.com/o/journal_categories%2Flearning.jpeg?alt=media&token=bf05ab63-0511-41dc-b452-cb818cdfdf2b",
        name: "Learning"),
    JournalCategory(
        image:
            "https://firebasestorage.googleapis.com/v0/b/level108-dev.appspot.com/o/journal_categories%2Fhappiness.jpeg?alt=media&token=cee1549b-c513-4ad7-9521-8de084b009f6",
        name: "Happiness"),
    JournalCategory(
        image:
            "https://firebasestorage.googleapis.com/v0/b/level108-dev.appspot.com/o/journal_categories%2Fdaily_reflection.png?alt=media&token=975bd0d7-ac65-4bca-8c84-c4d92f83c38b",
        name: "Daily Reflections")
  ];

  Future addJournalCategory({JournalCategory? journalCategory}) async {
    String? userId = FirebaseAuth.instance.currentUser?.uid;
    if (userId != null &&
        journalCategory?.name != null &&
        journalCategory!.name.isNotEmpty) {
      DocumentSnapshot<Category> documentSnapshot = await FirebaseFirestore
          .instance
          .collection(journalCollection)
          .doc(userId)
          .withConverter<Category>(
              fromFirestore: (snapshots, _) =>
                  Category.fromJson(snapshots.data()!),
              toFirestore: (category, _) => category.toJson())
          .get();
      if (documentSnapshot.data() != null) {
        Category category = documentSnapshot.data()!;
        List<JournalCategory>? categories = category.journalCategory;
        categories.add(journalCategory);
        category.journalCategory = categories;
        await FirebaseFirestore.instance
            .collection(journalCollection)
            .doc(userId)
            .withConverter<Category>(
                fromFirestore: (snapshots, _) =>
                    Category.fromJson(snapshots.data()!),
                toFirestore: (category, _) => category.toJson())
            .set(category);
      }
      getJournalCategories();
    } else if (userId != null) {
      Category category = Category(journalCategory: defaultJournalCategories);
      await FirebaseFirestore.instance
          .collection(journalCollection)
          .doc(userId)
          .withConverter<Category>(
              fromFirestore: (snapshots, _) =>
                  Category.fromJson(snapshots.data()!),
              toFirestore: (category, _) => category.toJson())
          .set(category)
          .catchError((error) {
        print("Error : $error");
      });
    }
  }

  getJournalCategories() {
    String? userId = FirebaseAuth.instance.currentUser?.uid;
    if (userId != null) {
      loadingJournalCategories.value = true;
      FirebaseFirestore.instance
          .collection(journalCollection)
          .doc(userId)
          .withConverter<Category>(
              fromFirestore: (snapshots, _) =>
                  Category.fromJson(snapshots.data()!),
              toFirestore: (category, _) => category.toJson())
          .get()
          .then((value) {
        if (value.data() != null) {
          Category category = value.data()!;
          List<JournalCategory>? val = category.journalCategory;
          loadingJournalCategories.value = false;
          journalCategories.value = val;
        }
      });
    }
  }

  getCourseCategories() {
    loadingCategories.value = true;
    courseCategories.clear();
    FirebaseFirestore.instance
        .collection(courseCategoriesLabel)
        .get()
        .then((value) async {
      await Future.forEach<QueryDocumentSnapshot>(value.docs, (element) async {
        var courseCategoryReference = await element.reference
            .withConverter<CourseCategory>(
                fromFirestore: (snapshots, _) =>
                    CourseCategory.fromJson(snapshots.data()!),
                toFirestore: (courseCategory, _) => courseCategory.toJson())
            .get();
        CourseCategory category = courseCategoryReference.data()!;
        category.fetchCourseDetails();
        if (courseCategoryReference.data() != null)
          courseCategories.add(category);
      });
      loadingCategories.value = false;
    });
  }

  Future<Course?> getCourseDetails(String courseId) async {
    if (courseId.contains(courseIdLabel))
      courseId = courseId.replaceAll(courseIdLabel, '');
    var courseCategoryReference = await FirebaseFirestore.instance
        .collection(coursesLabel)
        .doc('$courseIdLabel$courseId')
        .withConverter<Course>(
            fromFirestore: (snapshots, _) => Course.fromJson(snapshots.data()!),
            toFirestore: (course, _) => course.toJson())
        .get();
    return courseCategoryReference.data();
  }

  getLessonDetails(String lessonId) async {
    var lessonReference = await FirebaseFirestore.instance
        .collection(lessonsLabel)
        .doc(lessonId)
        .withConverter<Lesson>(
            fromFirestore: (snapshots, _) => Lesson.fromJson(snapshots.data()!),
            toFirestore: (lesson, _) => lesson.toJson())
        .get();
    return lessonReference.data();
  }

  getQuizDetails(String quizId) async {
    String? userId = FirebaseAuth.instance.currentUser?.uid;
    if (userId != null) {
      try {
        DocumentReference<Quiz> documentReference = FirebaseFirestore.instance
            .collection(courseProgression)
            .doc(userId)
            .collection(quizLabel)
            .doc(quizId)
            .withConverter<Quiz>(
                fromFirestore: (snapshots, _) =>
                    Quiz.fromJson(snapshots.data()!),
                toFirestore: (quiz, _) => quiz.toJson());
        Quiz? quiz = (await documentReference.get()).data();
        if (quiz != null) return quiz;
      } catch (e) {}
    }
    var lessonReference = await FirebaseFirestore.instance
        .collection(quizLabel)
        .doc(quizId)
        .withConverter<Quiz>(
            fromFirestore: (snapshots, _) => Quiz.fromJson(snapshots.data()!),
            toFirestore: (quiz, _) => quiz.toJson())
        .get();
    return lessonReference.data();
  }


  fetchFeaturedCourses(ValueChanged<List<Course>> onDataFetched) {
    FirebaseFirestore.instance
        .collection(coursesLabel)
        .withConverter<Course>(
            fromFirestore: (snapshots, _) => Course.fromJson(snapshots.data()!),
            toFirestore: (course, _) => course.toJson())
        .get()
        .then((value) {
      List<Course> courses = [];
      value.docs.forEach((element) {
        Course course = element.data();
        if (course.courseMetadata?.isFeatured ?? false) {
          courses.add(course);
        }
      });
      onDataFetched(courses);
    });
  }

  addProfile(Profile profile, ValueChanged<bool> onDataAdded) {
    String? userId = FirebaseAuth.instance.currentUser?.uid;
    if (userId != null) {
      FirebaseFirestore.instance
          .collection(profileLabel)
          .doc(userId)
          .set(profile.toJson())
          .then((value) {
        onDataAdded(true);
      }).catchError((error) {
        onDataAdded(false);
      });
    }
  }

  void getProfile(ValueChanged<Profile> onProfileFetch) {
    String? userId = FirebaseAuth.instance.currentUser?.uid;
    if (userId != null) {
      FirebaseFirestore.instance
          .collection(profileLabel)
          .doc(userId)
          .withConverter<Profile>(
              fromFirestore: (snapshots, _) =>
                  Profile.fromJson(snapshots.data()!),
              toFirestore: (profile, _) => profile.toJson())
          .get()
          .then((value) {
        if (value.data() != null) onProfileFetch(value.data()!);
      });
    }
  }

  Future<String?> addFiles(File file, {String path = ""}) async {
    Reference ref = FirebaseStorage.instance
        .ref()
        .child(path)
        .child('/${DateTime.now().microsecondsSinceEpoch.toString()}.jpg');
    final metadata = SettableMetadata(
        contentType: 'image/jpeg',
        customMetadata: {'picked-file-path': file.path});
    TaskSnapshot uploadTask = await ref.putFile(file, metadata);
    if (uploadTask.state == TaskState.success) {
      return await uploadTask.ref.getDownloadURL();
    } else {
      return null;
    }
  }

  getCoursesById(ValueChanged<Course?> onDataAdded, String courseId) {
    String? userId = FirebaseAuth.instance.currentUser?.uid;
    if (userId != null) {
      FirebaseFirestore.instance
          .collection(courseProgression)
          .doc(userId)
          .collection(coursesLabel)
          .doc('$courseIdLabel$courseId')
          .withConverter<Course>(
              fromFirestore: (snapshots, _) =>
                  Course.fromJson(snapshots.data()!),
              toFirestore: (course, _) => course.toJson())
          .get()
          .then((value) {
        onDataAdded(value.data());
      }).catchError((error) {
        onDataAdded(null);
      });
    }
  }

  Future<bool> addOrUpdateCoursesById(Course course,
      {bool isUpdate = false}) async {
    String? userId = FirebaseAuth.instance.currentUser?.uid;
    if (userId != null) {
      try {
        DocumentReference documentReference = FirebaseFirestore.instance
            .collection(courseProgression)
            .doc(userId)
            .collection(coursesLabel)
            .doc('$courseIdLabel${course.id}')
            .withConverter<Course>(
                fromFirestore: (snapshots, _) =>
                    Course.fromJson(snapshots.data()!),
                toFirestore: (course, _) => course.toJson());
        if (isUpdate) {
          await documentReference.update(course.toJson());
        } else {
          await documentReference.set(course);
        }
        return true;
      } catch (e) {
        return false;
      }
    }
    return true;
  }

  Future<bool> addQuizAnswer(Quiz quiz) async {
    String? userId = FirebaseAuth.instance.currentUser?.uid;
    if (userId != null) {
      try {
        DocumentReference documentReference = FirebaseFirestore.instance
            .collection(courseProgression)
            .doc(userId)
            .collection(quizLabel)
            .doc('$quizIdLabel${quiz.id}')
            .withConverter<Quiz>(
                fromFirestore: (snapshots, _) =>
                    Quiz.fromJson(snapshots.data()!),
                toFirestore: (quiz, _) => quiz.toJson());
        await documentReference.set(quiz);
        return true;
      } catch (e) {
        return false;
      }
    }
    return true;
  }

  getMyCourses(ValueChanged<List<Course>> onDataAdded) {
    String? userId = FirebaseAuth.instance.currentUser?.uid;
    if (userId != null) {
      FirebaseFirestore.instance
          .collection(courseProgression)
          .doc(userId)
          .collection(coursesLabel)
          .withConverter<Course>(
              fromFirestore: (snapshots, _) =>
                  Course.fromJson(snapshots.data()!),
              toFirestore: (course, _) => course.toJson())
          .get()
          .then((value) {
        List<Course> course = [];
        value.docs.forEach((element) {
          course.add(element.data());
        });
        onDataAdded(course);
      }).catchError((error) {
        onDataAdded([]);
      });
    }
  }



  addJournal(Journal journal, String journalCategory,
      ValueChanged<bool> onDataFetched) async {
    String? userId = FirebaseAuth.instance.currentUser?.uid;
    if (userId != null) {
      try {
        await FirebaseFirestore.instance
            .collection(journalCollection)
            .doc(userId)
            .collection(journalCategory)
            .doc(journal.id)
            .withConverter<Journal>(
                fromFirestore: (snapshots, _) =>
                    Journal.fromJson(snapshots.data()!),
                toFirestore: (journal, _) => journal.toJson())
            .set(journal);
        onDataFetched(true);
      } catch (e) {
        onDataFetched(false);
      }
    }
  }

  getJournalsByCategory(
      String category, ValueChanged<List<Journal>> onDataAdded) {
    String? userId = FirebaseAuth.instance.currentUser?.uid;
    if (userId != null) {
      FirebaseFirestore.instance
          .collection(journalCollection)
          .doc(userId)
          .collection(category)
          .withConverter<Journal>(
              fromFirestore: (snapshots, _) =>
                  Journal.fromJson(snapshots.data()!),
              toFirestore: (course, _) => course.toJson())
          .get()
          .then((value) {
        List<Journal> journals = [];
        value.docs.forEach((element) {
          journals.add(element.data());
        });
        onDataAdded(journals);
      }).catchError((error) {
        onDataAdded([]);
      });
    }
  }

  void deleteJournal(Journal journal, String journalCategory,
      ValueChanged<bool> onValueDelete) async {
    String? userId = FirebaseAuth.instance.currentUser?.uid;
    if (userId != null) {
      try {
        await FirebaseFirestore.instance
            .collection(journalCollection)
            .doc(userId)
            .collection(journalCategory)
            .doc(journal.id)
            .delete();
        onValueDelete(true);
      } catch (e) {
        onValueDelete(false);
      }
    }
  }

  Future<bool?> removeFile(String url) async {
    Reference ref = FirebaseStorage.instance.refFromURL(url);
    await ref.delete();
  }*/

  static DocumentSnapshot? _lastDeviceDocument;

  static DocumentSnapshot? get lastDeviceDocument => _lastDeviceDocument;

  static set setLastDeviceDocument(DocumentSnapshot? lastDeviceDocument) {
    _lastDeviceDocument = lastDeviceDocument;
  }

  static bool moreScrollEnable = true;

  getDevices(ValueChanged<List<Device>> onDataAdded) {
    Query<Device> query = FirebaseFirestore.instance
        .collection(deviceCollection)
        .withConverter<Device>(
            fromFirestore: (snapshots, _) => Device.fromJson(snapshots.data()!),
            toFirestore: (device, _) => device.toJson())
        .orderBy("name")
        .limit(10);

    if (_lastDeviceDocument != null) {
      query = query.startAfterDocument(_lastDeviceDocument!);
    } else {
      moreScrollEnable = true;
    }
    query.get().then((value) {
      _lastDeviceDocument = value.docs.last;

      if (value.docs.length < 10) moreScrollEnable = false;

      List<Device> devices = [];
      for (var element in value.docs) {
        Device _device = element.data();
        _device.id = element.id;
        devices.add(_device);
      }
      onDataAdded(devices);
    }).catchError((error) {
      onDataAdded([]);
    });
  }

  getUsers(ValueChanged<List<User>> onDataAdded) {
    FirebaseFirestore.instance
        .collection(userCollection)
        .withConverter<User>(
            fromFirestore: (snapshots, _) => User.fromJson(snapshots.data()!),
            toFirestore: (user, _) => user.toJson())
        .get()
        .then((value) {
      List<User> users = [];
      for (var _user in value.docs) {
        User user = User(name: _user.data().name, id: _user.id);
        users.add(user);
      }
      onDataAdded(users);
    }).catchError((error) {
      onDataAdded([]);
    });
  }

  Future<String> addDevice(String deviceName) async {
    var docRef = await FirebaseFirestore.instance
        .collection(deviceCollection)
        .add(Device(name: deviceName).toJson())
        .catchError((onError) {
      print(onError.toString());
    });
    return docRef.id;
  }

  Future<String> editDevice(String deviceName, String? id) async {
    await FirebaseFirestore.instance
        .collection(deviceCollection)
        .doc(id)
        .update({"name": deviceName}).catchError((onError) {
      print(onError.toString());
    });
    return deviceName;
  }

  Future<String> addUser(String userName) async {
    var docRef = await FirebaseFirestore.instance
        .collection(userCollection)
        .add({"name": userName}).catchError((onError) {
      print(onError.toString());
    });
    return docRef.id;
  }

  Future<void> selectUser(User user, Device device) async {
    await FirebaseFirestore.instance
        .collection(deviceCollection)
        .doc(device.id)
        .set(
      {
        "name": user.name,
        "user_id": user.id,
      },
    );

    return;
  }

  Future<String> editUser(String userName, String id) async {
    await FirebaseFirestore.instance
        .collection(userCollection)
        .doc(id)
        .update({"name": userName}).catchError((onError) {
      print(onError.toString());
    });
    return userName;
  }
}
