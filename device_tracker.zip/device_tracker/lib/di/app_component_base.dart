import 'dart:async';

import 'package:device_tracker/di/network_manager.dart';
import 'package:device_tracker/di/shared_preference.dart';

class AppComponentBase extends AppComponentBaseRepository {
  static AppComponentBase? _instance;
  final NetworkManager _networkManager = NetworkManager();
  final StreamController<bool> _progressDialogStreamController = StreamController.broadcast();
  final SharedPreference _sharedPreference = SharedPreference();
  Stream<bool?> get progressDialogStream => _progressDialogStreamController.stream;

  static final AppComponentBase _appComponentBase = AppComponentBase._privateConstructor();
  AppComponentBase._privateConstructor();
  static AppComponentBase get instance => _appComponentBase;

  //
  // static AppComponentBase? getInstance() {
  //   if (_instance == null) {
  //     _instance = AppComponentBase();
  //   }
  //   return _instance;
  // }

  init() async {
    await _networkManager.initialiseNetworkManager();
    await _sharedPreference.initPreference();
  }

  shoProgressDialog(bool value){
    _progressDialogStreamController.sink.add(value);
  }


  dispose(){
    _progressDialogStreamController.close();
    _networkManager.disposeStream();
  }

  @override
  SharedPreference getSharedPreference() {
    return _sharedPreference;
  }

  @override
  NetworkManager getNetworkManager() {
    return _networkManager;
  }

}

abstract class AppComponentBaseRepository {

  SharedPreference getSharedPreference();

  NetworkManager getNetworkManager();
}
