import 'package:device_tracker/di/app_component_base.dart';
import 'package:device_tracker/di/firesore_manager.dart';
import 'package:device_tracker/models/device.dart';
import 'package:device_tracker/models/user.dart';
import 'package:device_tracker/ui/deviceboard/adapters/repository_adapter.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class DeviceController extends SuperController<List<Device>> {
  DeviceController({required this.dashboardRepository});

  final IDeviceRepository dashboardRepository;
  RxList<User>? userList = <User>[].obs;
  RxList<Device> deviceList = <Device>[].obs;

  ScrollController scrollController = ScrollController();
  static bool isLoaded = true;

  @override
  void onInit() {
    super.onInit();
    dashboardRepository.getUsers((users) {
      // userList = users.obs;

      var _userList = users.obs;
      userList!.clear();
      userList!.add(User(name: "In the box"));
      userList!.addAll(_userList);

      FirestoreManager.setLastDeviceDocument = null;
      deviceList.clear();
      getDevice();
      // value!.toList().length;
    });

    scrollController.addListener(() {
      if (scrollController.position.maxScrollExtent ==
          scrollController.position.pixels)
      // if (scrollController.position.maxScrollExtent > scrollController.offset &&
      //     scrollController.position.maxScrollExtent - scrollController.offset <=
      //         50)
      {
        if (isLoaded && FirestoreManager.moreScrollEnable) {
          isLoaded = false;
          getDevice();
        }
      }
    });

    //Loading, Success, Error handle with 1 line of code
  }

  void addDevice(String deviceName) {
    dashboardRepository.addDevice(deviceName).then((_id) {
      FirestoreManager.setLastDeviceDocument = null;
      deviceList.clear();
      getDevice();
    });
  }

  void getDevice() {
    AppComponentBase.instance.shoProgressDialog(true);

    dashboardRepository.getDevice((devices) {
      isLoaded = true;
      for (var device in devices) {
        device.user = userList![0];
        if (device.user_id != null && device.user_id!.isNotEmpty) {
          var userWheres = userList!.where(
              (_user) => _user.id.toString() == device.user_id.toString());
          if (userWheres != null && userWheres.isNotEmpty) {
            device.user = userWheres.toList()[0];
          }
        }
      }
      deviceList.addAll(devices);
      AppComponentBase.instance.shoProgressDialog(false);

      append(() => () async => deviceList);
    });
  }

  void editDevice(String deviceName, String? id) {
    dashboardRepository.editDevice(deviceName, id).then((value) {
      FirestoreManager.setLastDeviceDocument = null;
      deviceList.clear();
      getDevice();
    });
  }

  void addUser(String userName) {
    dashboardRepository.addUser(userName).then((_id) {
      userList!.add(User(name: userName, id: _id));
    });
  }

  void editUser(String userName, String id) {
    AppComponentBase.instance.shoProgressDialog(true);
    dashboardRepository.editUser(userName, id).then((value) {
      userList!.firstWhere((user) => user.id == id).name = userName;
      AppComponentBase.instance.shoProgressDialog(false);
    });
  }

  void selectUser(User user, Device device) {
    dashboardRepository.selectUser(user, device);
  }

  @override
  void onReady() {
    print('The build method is done. '
        'Your controller is ready to call dialogs and snackbars');
    super.onReady();
  }

  @override
  void onClose() {
    print('onClose called');
    super.onClose();
  }

  @override
  void didChangeMetrics() {
    print('the window size did change');
    super.didChangeMetrics();
  }

  @override
  void didChangePlatformBrightness() {
    print('platform change ThemeMode');
    super.didChangePlatformBrightness();
  }

  @override
  Future<bool> didPushRoute(String route) {
    print('the route $route will be open');
    return super.didPushRoute(route);
  }

  @override
  Future<bool> didPopRoute() {
    print('the current route will be closed');
    return super.didPopRoute();
  }

  @override
  void onDetached() {
    print('onDetached called');
    scrollController.dispose();
  }

  @override
  void onInactive() {
    print('onInative called');
  }

  @override
  void onPaused() {
    print('onPaused called');
  }

  @override
  void onResumed() {
    print('onResumed called');
  }
}
