import 'package:device_tracker/enum/font_type.dart';
import 'package:device_tracker/models/device.dart';
import 'package:device_tracker/models/user.dart';
import 'package:device_tracker/ui/common/strings.dart';
import 'package:device_tracker/ui/common/widgets/app_theme.dart';
import 'package:device_tracker/ui/common/widgets/shimmer_widget.dart';
import 'package:device_tracker/ui/deviceboard/presentation/controllers/device_controller.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class DeviceView extends GetView<DeviceController> {
  const DeviceView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final _appTheme = AppTheme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: Text(StringConstants.devices,
            style: _appTheme.customTextStyle(
                fontSize: 50,
                color: _appTheme.whiteColor,
                fontFamilyType: FontFamilyType.ProzaLibre,
                fontWeightType: FontWeightType.Bold)),
        backgroundColor: _appTheme.primaryColor,
        actions: [
          GestureDetector(
            onTap: () => showAddDialogUserDevice(
                context,
                "Enter new user",
                'User Name',
                'eg. John smith',
                'Please enter user name',
                true,
                false,
                null,
                null),
            child: const Padding(
              padding: EdgeInsets.all(8.0),
              child: Icon(Icons.person_add_alt_1_sharp),
            ),
          ),
          GestureDetector(
            onTap: () => showAddDialogUserDevice(
                context,
                "Enter new device",
                'Device Name',
                'eg. Samsung note10',
                'Please enter device name',
                false,
                false,
                null,
                null),
            child: const Padding(
              padding: EdgeInsets.all(8.0),
              child: Icon(Icons.mobile_friendly),
            ),
          ),
        ],
      ),
      body: SafeArea(
        bottom: false,
        child: controller.obx(
          (state) {
            return ListView.builder(
              controller: controller.scrollController,
              itemBuilder: (context, index) {
                if (state is List) {
                  return _getPostWidget(state?[index], _appTheme, context);
                } else {
                  return const Offstage();
                }
              },
              // shrinkWrap: true,
              padding: EdgeInsets.symmetric(
                  vertical: _appTheme.getResponsiveHeight(20)),
              itemCount: state != null && state is List && state.isNotEmpty
                  ? state.length
                  : 0,
            );
          },
          onLoading: ListView.separated(
              itemBuilder: (context, index) {
                return _getPostShimmer(_appTheme);
              },
              separatorBuilder: (context, index) {
                return Padding(
                  padding: EdgeInsets.symmetric(
                      horizontal: _appTheme.getResponsiveWidth(70)),
                  child: Divider(
                    thickness: _appTheme.getResponsiveHeight(2),
                    color: _appTheme.dividerColor,
                  ),
                );
              },
              shrinkWrap: true,
              padding: EdgeInsets.symmetric(
                  vertical: _appTheme.getResponsiveHeight(20)),
              itemCount: 20),
        ),
      ),
    );
  }

  void showAddDialogUserDevice(
      BuildContext context,
      String title,
      String labelText,
      String hintText,
      String _errorText,
      bool isUser,
      bool isEdit,
      Device? device,
      User? user) {
    showDialog(
      context: context,
      builder: (context) {
        final GlobalKey<FormFieldState> _formKey = GlobalKey<FormFieldState>();
        Rx<String?> errorText = null.obs;

        TextEditingController textEditController;
        if (isEdit) {
          textEditController =
              TextEditingController(text: isUser ? user!.name : device!.name);
        } else {
          textEditController = TextEditingController();
        }

        return AlertDialog(
          shape: const RoundedRectangleBorder(),
          title: Column(
            children: [
              Text(title),
              const SizedBox(height: 8),
              Obx(() {
                return TextFormField(
                  key: _formKey,
                  controller: textEditController,
                  autofocus: true,
                  decoration: InputDecoration(
                    labelText: labelText,
                    hintText: hintText,
                    errorText: errorText.value,
                  ),
                  validator: (text) {
                    if (text == null || text.isEmpty) {
                      errorText = _errorText.obs;
                      return _errorText;
                    }
                    return null;
                  },
                );
              })
            ],
          ),
          actions: [
            TextButton(
                child: const Text('CANCEL'),
                onPressed: () => Navigator.pop(context)),
            TextButton(
                child: const Text('ADD'),
                onPressed: () {
                  _formKey.currentState!.validate();
                  if (textEditController.text.isNotEmpty) {
                    if (isUser) {
                      if (!isEdit) {
                        controller.addUser(textEditController.text);
                      } else {
                        controller.editUser(user!.name!, user.id!);
                      }
                    } else {
                      if (!isEdit) {
                        controller.addDevice(textEditController.text);
                      } else {
                        controller.editDevice(
                            textEditController.text, device!.id);
                      }
                    }
                    Navigator.pop(context);
                  }
                }),
          ],
        );
      },
    );
  }

  Widget _getPostShimmer(AppThemeState _appTheme) {
    return Padding(
      padding: EdgeInsets.symmetric(
          horizontal: _appTheme.getResponsiveWidth(70),
          vertical: _appTheme.getResponsiveHeight(20)),
      child: Column(
        children: <Widget>[
          ShimmerWidget(
              width: double.infinity,
              height: _appTheme.getResponsiveHeight(50),
              borderRadius: 5),
          SizedBox(height: _appTheme.getResponsiveHeight(10)),
          ShimmerWidget(
              width: double.infinity,
              height: _appTheme.getResponsiveHeight(50),
              borderRadius: 5),
        ],
      ),
    );
  }

  Widget _getPostWidget(
      Device? device, AppThemeState _appTheme, BuildContext context) {
    Rx<User?> selectedUser = device!.user.obs;
    return Padding(
      padding:
          EdgeInsets.symmetric(horizontal: _appTheme.getResponsiveWidth(20)),
      child: InkWell(
        onTap: () {
          showAddDialogUserDevice(
              context,
              "Edit device name",
              'Device Name',
              'eg. Samsung note10',
              'Please enter device name',
              false,
              true,
              device,
              null);
        },
        child: Card(
          elevation: 3,
          child: Padding(
            padding: EdgeInsets.symmetric(
                horizontal: _appTheme.getResponsiveWidth(36),
                vertical: _appTheme.getResponsiveHeight(20)),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Text(device.name ?? "",
                    style: _appTheme.customTextStyle(
                        fontSize: 60,
                        color: _appTheme.blackColor,
                        fontFamilyType: FontFamilyType.ProzaLibre,
                        fontWeightType: FontWeightType.Bold)),
                Flexible(child: Container()),
                Obx(() {
                  return DropdownButton<User>(
                    hint: const Text('Select User'),
                    items: controller.userList!.value
                        .map((user) => DropdownMenuItem<User>(
                              value: user,
                              child: GestureDetector(
                                onLongPressUp: () {
                                  if(user.name != 'In the box'){
                                    showAddDialogUserDevice(
                                        context,
                                        "Edit user name",
                                        'User Name',
                                        'eg. John smith',
                                        'Please enter user name',
                                        true,
                                        true,
                                        null,
                                        user);
                                  }
                                },
                                child: Text(user.name!),
                              ),
                            ))
                        .toList(),
                    onChanged: (user) {
                      // selectedUser = User(name: "Samir").obs;
                      selectedUser.value = user;
                      device.user = user;
                      controller.selectUser(user!, device);
                    },
                    value: selectedUser.value,
                  );
                })
              ],
            ),
          ),
        ),
      ),
    );
  }
}
