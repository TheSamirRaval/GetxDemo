import 'package:device_tracker/models/device.dart';
import 'package:device_tracker/models/user.dart';
import 'package:flutter/material.dart';

abstract class IDeviceRepository {
  void getDevice(ValueChanged<List<Device>> onDataAdded);

  void getUsers(ValueChanged<List<User>> onUserAdded);

  Future<String> addDevice(String deviceName);

  Future<String> editDevice(String deviceName, String? id);

  Future<String> addUser(String userName);

  Future<String> editUser(String userName, String id);

  Future<void> selectUser(User user, Device device);


// Future<Object> uploadFile(File file);
}
