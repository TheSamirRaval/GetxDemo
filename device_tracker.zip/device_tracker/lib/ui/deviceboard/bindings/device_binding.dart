import 'package:device_tracker/ui/deviceboard/adapters/repository_adapter.dart';
import 'package:device_tracker/ui/deviceboard/presentation/controllers/device_controller.dart';
import 'package:get/get.dart';
import '../data/deviceboard_api_provider.dart';

import '../data/deviceboard_repository.dart';

class DeviceBinding extends Bindings {

  @override
  void dependencies() {
    Get.lazyPut<IDeviceProvider>(() => DeviceProvider());
    Get.lazyPut<IDeviceRepository>(() => DeviceRepository(provider: Get.find()));
    Get.lazyPut(() => DeviceController(dashboardRepository: Get.find()));
  }
}
