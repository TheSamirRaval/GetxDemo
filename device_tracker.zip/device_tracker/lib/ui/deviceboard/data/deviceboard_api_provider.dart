import 'package:device_tracker/di/firesore_manager.dart';
import 'package:device_tracker/models/device.dart';
import 'package:device_tracker/models/user.dart';
import 'package:flutter/material.dart';

abstract class IDeviceProvider {
  getDevices(ValueChanged<List<Device>> onDataAdded);

  getUsers(ValueChanged<List<User>> onDataAdded);

  Future<String> addDevices(String deviceName);

  Future<String> editDevice(String deviceName, String? id);

  Future<String> addUser(String deviceName);

  Future<void> selectUser(User user, Device device);

  Future<String> editUser(String userName, String id);

// Future<Response<Object>> uploadFile(String path, File file);
}

class DeviceProvider implements IDeviceProvider {
  @override
  getDevices(ValueChanged<List<Device>> onDataAdded) {
    FirestoreManager.instance.getDevices((value) {
      if (value != null) {
        onDataAdded(value);
      }
    });
    // getMethod<List<Post>>(path,
    //     decoder: (val) => ApiClient.convertMapToObject<Post>(val));
  }

  @override
  Future<String> addDevices(String deviceName) async {
    return await FirestoreManager.instance.addDevice(deviceName);
  }

  @override
  Future<String> addUser(String userName) async {
    return await FirestoreManager.instance.addUser(userName);
  }

  @override
  getUsers(ValueChanged<List<User>> onDataAdded) {
    FirestoreManager.instance.getUsers((value) {
      if (value != null) {
        onDataAdded(value);
      }
    });
  }

  @override
  Future<void> selectUser(User user, Device device) async {
    await FirestoreManager.instance.selectUser(user, device);
    return;
  }

  @override
  Future<String> editDevice(String deviceName, String? id) async {
    return await FirestoreManager.instance.editDevice(deviceName, id);
  }

  @override
  Future<String> editUser(String userName, String id) async {
    return await FirestoreManager.instance.editUser(userName, id);
  }

// @override
// Future<Response<Object>> uploadFile(String path, File file) {
//   final form = FormData({
//     'file': MultipartFile(file, filename: 'avatar.png'),
//   });
//   // return post(path, form);
//   return Object;
// }

}
