import 'package:device_tracker/models/device.dart';
import 'package:device_tracker/models/user.dart';
import 'package:device_tracker/ui/deviceboard/adapters/repository_adapter.dart';
import 'package:flutter/material.dart';

import 'deviceboard_api_provider.dart';

class DeviceRepository implements IDeviceRepository {
  DeviceRepository({required this.provider});

  final IDeviceProvider provider;

  /*@override
  Future<List<Device>> getPosts() async {
    final cases = await provider.getPosts("posts");
    if (cases.status.hasError) {
      return Future.error(cases.statusText!);
    } else {
      return cases.body!;
    }
  }*/

  /* @override
  Future<Object> uploadFile(File file) async {
    final cases = await provider.uploadFile("upload", file);
    if (cases.status.hasError) {
      return Future.error(cases.statusText!);
    } else {
      return cases.body!;
    }
  }*/

  @override
  getDevice(ValueChanged<List<Device>> onDataAdded) async {
    provider.getDevices((value) => onDataAdded(value));

    // if (cases.status.hasError) {
    //   return Future.error(cases.statusText!);
    // } else {
    //   return cases.body!;
    // }
  }

  @override
  Future<String> addDevice(String deviceName) async {
    return await provider.addDevices(deviceName);
  }

  @override
  Future<String> addUser(String userName) {
    return provider.addUser(userName);
  }

  @override
  void getUsers(ValueChanged<List<User>> onUserAdded) {
    provider.getUsers((value) => onUserAdded(value));
  }

  @override
  Future<void> selectUser(User user, Device device) {
    return provider.selectUser(user, device);
  }

  @override
  Future<String> editDevice(String deviceName, String? id) {
    return provider.editDevice(deviceName,id);
  }

  @override
  Future<String> editUser(String userName, String id) {
    return provider.editUser(userName,id);
  }
}
