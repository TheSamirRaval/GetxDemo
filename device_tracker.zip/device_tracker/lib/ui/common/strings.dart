class StringConstants {
  static const String noInternetConnection =
      "Please check your Internet connection";
  static const String posts = "Posts";
  static const String devices = "Devices";
  static const String profile = "Profile";

  static var sorry = "Sorry";
}
