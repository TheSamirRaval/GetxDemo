class SVGPath {
  static const String cancel = "assets/svg/cancel.svg";
  static const String menu = "assets/svg/menu.svg";
}

class PNGPath {
  static const String tick = "assets/png/tick.png";
}
