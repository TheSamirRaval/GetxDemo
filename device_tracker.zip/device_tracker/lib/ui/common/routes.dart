import 'package:device_tracker/ui/deviceboard/bindings/device_binding.dart';
import 'package:device_tracker/ui/deviceboard/presentation/views/deviceboard_view.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class RouteName {
  static const INITIAL = root;

  // Base routes
  static const String root = "/";
  // static final String profilePage = "/profile";
}

class Routes {
  static final routes = [
    GetPage(
      page: () => DeviceView(),
      name: RouteName.root,
      binding: DeviceBinding(),
      // children: [
      //   GetPage(
      //     page: () => ProfileView(),
      //     name: RouteName.profilePage,
      //   )
      // ],
    )
  ];
  static final commonRoutes = <String, WidgetBuilder>{};
}
