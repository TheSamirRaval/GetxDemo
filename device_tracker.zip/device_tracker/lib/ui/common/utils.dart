class Utils {
  static const animationDuration = Duration(milliseconds: 200);
}
